﻿Imports System.Data.OleDb
Imports System.IO
Public Class CheckMemberDetails

    'For database uses only (*)
    Dim provider As String
    Dim dataFile As String
    Dim connString As String
    Dim myConnection As OleDbConnection = New OleDbConnection
    Dim dr As OleDbDataReader

    Private Sub CheckMemberDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'For database uses only (*)
        provider = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source ="
        dataFile = Login.strFileName & "Starbucks_Database.accdb"
        connString = provider & dataFile
        myConnection.ConnectionString = connString

        display_Member_Details()

        Timer1.Start()
    End Sub

    Private Sub picfbpage_Click(sender As Object, e As EventArgs) Handles picfbpage.Click
        Dim fbPage As String = Login.strFileName & "Resources\Starbucks.html"
        Process.Start(fbPage)
    End Sub

    Private Sub display_Member_Details()
        myConnection.Open()
        Dim strQuery As String
        'Clear the records in the DataGridView1
        DataGridView1.Rows.Clear()

        'Construct columns
        DataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridView1.BackgroundColor = System.Drawing.SystemColors.Control

        DataGridView1.ColumnCount = 11
        DataGridView1.Columns(0).Name = "Username"
        DataGridView1.Columns(1).Name = "First Name"
        DataGridView1.Columns(2).Name = "Last Name"
        DataGridView1.Columns(3).Name = "Password"
        DataGridView1.Columns(4).Name = "NRIC"
        DataGridView1.Columns(5).Name = "Email Address"
        DataGridView1.Columns(6).Name = "Phone Number"
        DataGridView1.Columns(7).Name = "Gender"
        DataGridView1.Columns(8).Name = "UserType"
        DataGridView1.Columns(9).Name = "Birth Date"
        DataGridView1.Columns(10).Name = "Account Balance(RM)"

        Me.DataGridView1.Font = New Font("Comic Sans Ms", 10)

        Dim row As Object()
        strQuery = "SELECT * FROM Members"
        Dim cmd As OleDbCommand = New OleDbCommand(strQuery, myConnection)
        dr = cmd.ExecuteReader
        While dr.Read()
            'construct rows
            row = New Object() {dr("Username").ToString, dr("FirstName").ToString, dr("LastName").ToString, dr("Password").ToString, _
                                dr("NRIC").ToString, dr("Email").ToString, dr("PhoneNumber").ToString, dr("Gender").ToString, _
                                dr("UserType").ToString, Format(dr("BirthDate"), "dd/MM/yyyy"), FormatNumber(dr("CurrentAmount"), 2)}
            DataGridView1.Rows.Add(row)
        End While
        myConnection.Close()
    End Sub

    Private Sub DataGridView1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.Click
        Dim i As Integer
        For intCount As Integer = 0 To DataGridView1.RowCount - 1 Step 1
            DataGridView1.Rows(intCount).DefaultCellStyle.BackColor = Color.White
        Next
        i = DataGridView1.CurrentRow.Index
        DataGridView1.Rows(i).DefaultCellStyle.BackColor = Color.Pink
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim strSearchName As String
        Dim intRow As Integer
        Dim blnExist As Boolean = False

        If txtSearch.Text = "" Then
            MessageBox.Show("Invalid input..." & vbCr & "Please re-enter the username.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtSearch.Text = ""
            txtSearch.Focus()
        Else
            strSearchName = CStr(txtSearch.Text)
            For intRow = 0 To DataGridView1.RowCount - 1 Step 1
                If String.Compare(DataGridView1.Item(0, intRow).Value, strSearchName) = 0 Then
                    DataGridView1.FirstDisplayedScrollingRowIndex = intRow
                    DataGridView1.Rows(intRow).DefaultCellStyle.BackColor = Color.Pink
                    blnExist = True
                Else
                    DataGridView1.Rows(intRow).DefaultCellStyle.BackColor = Color.White
                End If
            Next

            If blnExist = False Then
                MessageBox.Show("This username does not exist..." & vbCr & "Please re-enter the username.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtSearch.Text = ""
                txtSearch.Focus()
            End If
        End If
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        Dim FileToDelete As String = Login.strFileName & "myCart.txt"

        If File.Exists(FileToDelete) = True Then
            File.Delete(FileToDelete)
        End If

        Login.Close()
        Login.Show()
        Me.Close()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        Dim objReader As New StreamReader(Login.strFileName & "Resources\Instruction.txt")
        Dim strText As String
        Dim strArray(8) As String

        While objReader.Peek <> -1
            strText = objReader.ReadToEnd
            strArray = strText.Split("#")
        End While

        MessageBox.Show(strArray(5), "HELP", MessageBoxButtons.OK, MessageBoxIcon.Information)
        objReader.Close()
    End Sub

    Private Sub CheckStockToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CheckStockToolStripMenuItem.Click
        CheckStock.Show()
        Me.Close()
    End Sub

    Private Sub OrderFromSupplierToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OrderFromSupplierToolStripMenuItem.Click
        OrderFromSupplier.Show()
        Me.Close()
    End Sub

    Private Sub GenerateReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GenerateReportToolStripMenuItem.Click
        GenerateReport.Show()
        Me.Close()
    End Sub

    Private Sub MyAccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MyAccountToolStripMenuItem.Click
        MyAccount.Show()
        Me.Close()
    End Sub

    Private Sub TopUpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TopUpToolStripMenuItem.Click
        TopUp.Show()
        Me.Close()
    End Sub

    Private Sub PaymentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PaymentToolStripMenuItem.Click
        Payment.Show()
        Me.Close()
    End Sub

    Private Sub MyCartToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MyCartToolStripMenuItem.Click
        MyCart.Show()
        Me.Close()
    End Sub

    Private Sub ProductToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductToolStripMenuItem.Click
        Product.Show()
        Me.Close()
    End Sub

    Private Sub MemberRegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MemberRegistrationToolStripMenuItem.Click
        Registration.Show()
        Me.Close()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblTime.Text = "Date: " & Format(Date.Now(), "dd/MM/yy") & vbCr & "Time: " & TimeOfDay.ToString("h:mm:ss tt")
    End Sub
End Class
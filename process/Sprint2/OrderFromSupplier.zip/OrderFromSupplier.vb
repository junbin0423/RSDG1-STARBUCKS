﻿Imports System.Data.OleDb
Imports System.IO
Public Class OrderFromSupplier

    'For database uses only (*)
    Dim provider As String
    Dim dataFile As String
    Dim connString As String
    Dim myConnection As OleDbConnection = New OleDbConnection
    Dim dr As OleDbDataReader

    Private Sub OrderFromSupplier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'For database uses only (*)
        provider = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source ="
        dataFile = Login.strFileName & "Starbucks_Database.accdb"
        connString = provider & dataFile
        myConnection.ConnectionString = connString

        display_SupplierName_InCboSupplier()

        Timer1.Start()
    End Sub

    Private Sub picFbPage_Click(sender As Object, e As EventArgs) Handles picFbPage.Click
        Process.Start(Login.strFileName & "Resources\Starbucks.html")
    End Sub

    Private Sub display_SupplierName_InCboSupplier()
        myConnection.Open()
        Dim strQuery As String = "SELECT SupplierName FROM Suppliers"
        Dim cmd As OleDbCommand = New OleDbCommand(strQuery, myConnection)
        dr = cmd.ExecuteReader
        While dr.Read
            CboSupplier.Items.Add(dr("SupplierName").ToString)
        End While
        myConnection.Close()
    End Sub

    Private Sub item_In_cboProductID()
        myConnection.Open()
        Dim strQuery As String = "SELECT DISTINCT P.ProductID FROM Products P, SupplierLists SL, Suppliers S " & _
            "WHERE P.ProductID = SL.ProductID AND SL.SupplierID = S.SupplierID AND S.SupplierName LIKE '" & CboSupplier.Text & "'"

        Dim cmd As OleDbCommand = New OleDbCommand(strQuery, myConnection)
        dr = cmd.ExecuteReader
        While dr.Read()
            cboProductID.Items.Add(dr("ProductID").ToString)
        End While
        myConnection.Close()
    End Sub

    Private Sub CboSupplier_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CboSupplier.SelectedIndexChanged
        CboProductID.Items.Clear()
        item_In_cboProductID()
    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        Dim ord As New ConfirmOrderWithSupplier
        ord.productID = CboProductID.Text
        ord.supplierName = CboSupplier.Text
        ord.Show()
        Me.Hide()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        Dim objReader As New StreamReader(Login.strFileName & "Resources\Instruction.txt")
        Dim strText As String
        Dim strArray(8) As String

        While objReader.Peek <> -1
            strText = objReader.ReadToEnd
            strArray = strText.Split("#")
        End While

        MessageBox.Show(strArray(7), "HELP", MessageBoxButtons.OK, MessageBoxIcon.Information)
        objReader.Close()
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        Dim FileToDelete As String = Login.strFileName & "myCart.txt"

        If File.Exists(FileToDelete) = True Then
            File.Delete(FileToDelete)
        End If

        Login.Close()
        Login.Show()
        Me.Close()
    End Sub

    Private Sub CheckMembersDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CheckMembersDetailsToolStripMenuItem.Click
        CheckMemberDetails.Show()
        Me.Close()
    End Sub

    Private Sub CheckStockToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CheckStockToolStripMenuItem.Click
        CheckStock.Show()
        Me.Close()
    End Sub

    Private Sub GenerateReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GenerateReportToolStripMenuItem.Click
        GenerateReport.Show()
        Me.Close()
    End Sub

    Private Sub MyAccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MyAccountToolStripMenuItem.Click
        MyAccount.Show()
        Me.Close()
    End Sub

    Private Sub TopUpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TopUpToolStripMenuItem.Click
        TopUp.Show()
        Me.Close()
    End Sub

    Private Sub PaymentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PaymentToolStripMenuItem.Click
        Payment.Show()
        Me.Close()
    End Sub

    Private Sub MyCartToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MyCartToolStripMenuItem.Click
        MyCart.Show()
        Me.Close()
    End Sub

    Private Sub ProductToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductToolStripMenuItem.Click
        Product.Show()
        Me.Close()
    End Sub

    Private Sub MemberRegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MemberRegistrationToolStripMenuItem.Click
        Registration.Show()
        Me.Close()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblTime.Text = "Date: " & Format(Date.Now(), "dd/MM/yy") & vbCr & "Time: " & TimeOfDay.ToString("h:mm:ss tt")
    End Sub
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OrderFromSupplier
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(OrderFromSupplier))
        Me.picLogo = New System.Windows.Forms.PictureBox()
        Me.btnView = New System.Windows.Forms.Button()
        Me.CboSupplier = New System.Windows.Forms.ComboBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CboProductID = New System.Windows.Forms.ComboBox()
        Me.lblSupplier = New System.Windows.Forms.Label()
        Me.picFbPage = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ProductToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MyCartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TopUpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MyAccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdminToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckMembersDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckStockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrderFromSupplierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GenerateReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MemberRegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.picFbPage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'picLogo
        '
        Me.picLogo.BackColor = System.Drawing.Color.Transparent
        Me.picLogo.Image = CType(resources.GetObject("picLogo.Image"), System.Drawing.Image)
        Me.picLogo.Location = New System.Drawing.Point(12, 51)
        Me.picLogo.Name = "picLogo"
        Me.picLogo.Size = New System.Drawing.Size(123, 74)
        Me.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLogo.TabIndex = 68
        Me.picLogo.TabStop = False
        '
        'btnView
        '
        Me.btnView.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnView.Location = New System.Drawing.Point(156, 331)
        Me.btnView.Name = "btnView"
        Me.btnView.Size = New System.Drawing.Size(107, 45)
        Me.btnView.TabIndex = 30
        Me.btnView.Text = "View"
        Me.ToolTip1.SetToolTip(Me.btnView, "Click here to view the product details.")
        Me.btnView.UseVisualStyleBackColor = True
        '
        'CboSupplier
        '
        Me.CboSupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CboSupplier.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboSupplier.FormattingEnabled = True
        Me.CboSupplier.Location = New System.Drawing.Point(21, 73)
        Me.CboSupplier.Name = "CboSupplier"
        Me.CboSupplier.Size = New System.Drawing.Size(383, 31)
        Me.CboSupplier.TabIndex = 25
        Me.ToolTip1.SetToolTip(Me.CboSupplier, "Please select the supplier here.")
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 30)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(420, 433)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 29
        Me.PictureBox1.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnView)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.CboProductID)
        Me.GroupBox1.Controls.Add(Me.lblSupplier)
        Me.GroupBox1.Controls.Add(Me.CboSupplier)
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Font = New System.Drawing.Font("Comic Sans MS", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(155, 51)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(426, 466)
        Me.GroupBox1.TabIndex = 70
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Order From Supplier"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(18, 121)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 18)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Product ID:"
        '
        'CboProductID
        '
        Me.CboProductID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CboProductID.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CboProductID.FormattingEnabled = True
        Me.CboProductID.Location = New System.Drawing.Point(21, 154)
        Me.CboProductID.Name = "CboProductID"
        Me.CboProductID.Size = New System.Drawing.Size(383, 31)
        Me.CboProductID.TabIndex = 27
        Me.ToolTip1.SetToolTip(Me.CboProductID, "Please select the Product ID here.")
        '
        'lblSupplier
        '
        Me.lblSupplier.AutoSize = True
        Me.lblSupplier.BackColor = System.Drawing.SystemColors.Control
        Me.lblSupplier.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSupplier.Location = New System.Drawing.Point(18, 37)
        Me.lblSupplier.Name = "lblSupplier"
        Me.lblSupplier.Size = New System.Drawing.Size(106, 18)
        Me.lblSupplier.TabIndex = 26
        Me.lblSupplier.Text = "Select Supplier:"
        '
        'picFbPage
        '
        Me.picFbPage.BackColor = System.Drawing.Color.White
        Me.picFbPage.Cursor = System.Windows.Forms.Cursors.Hand
        Me.picFbPage.Image = CType(resources.GetObject("picFbPage.Image"), System.Drawing.Image)
        Me.picFbPage.Location = New System.Drawing.Point(12, 444)
        Me.picFbPage.Name = "picFbPage"
        Me.picFbPage.Size = New System.Drawing.Size(137, 36)
        Me.picFbPage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picFbPage.TabIndex = 69
        Me.picFbPage.TabStop = False
        Me.ToolTip1.SetToolTip(Me.picFbPage, "Click here to find us on facebook.")
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.Control
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProductToolStripMenuItem, Me.MyCartToolStripMenuItem, Me.PaymentToolStripMenuItem, Me.TopUpToolStripMenuItem, Me.MyAccountToolStripMenuItem, Me.AdminToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(594, 25)
        Me.MenuStrip1.TabIndex = 80
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ProductToolStripMenuItem
        '
        Me.ProductToolStripMenuItem.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProductToolStripMenuItem.Name = "ProductToolStripMenuItem"
        Me.ProductToolStripMenuItem.Size = New System.Drawing.Size(71, 21)
        Me.ProductToolStripMenuItem.Text = "Product"
        '
        'MyCartToolStripMenuItem
        '
        Me.MyCartToolStripMenuItem.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MyCartToolStripMenuItem.Name = "MyCartToolStripMenuItem"
        Me.MyCartToolStripMenuItem.Size = New System.Drawing.Size(69, 21)
        Me.MyCartToolStripMenuItem.Text = "My Cart"
        '
        'PaymentToolStripMenuItem
        '
        Me.PaymentToolStripMenuItem.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PaymentToolStripMenuItem.Name = "PaymentToolStripMenuItem"
        Me.PaymentToolStripMenuItem.Size = New System.Drawing.Size(76, 21)
        Me.PaymentToolStripMenuItem.Text = "Payment"
        '
        'TopUpToolStripMenuItem
        '
        Me.TopUpToolStripMenuItem.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TopUpToolStripMenuItem.Name = "TopUpToolStripMenuItem"
        Me.TopUpToolStripMenuItem.Size = New System.Drawing.Size(65, 21)
        Me.TopUpToolStripMenuItem.Text = "Top Up"
        '
        'MyAccountToolStripMenuItem
        '
        Me.MyAccountToolStripMenuItem.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MyAccountToolStripMenuItem.Name = "MyAccountToolStripMenuItem"
        Me.MyAccountToolStripMenuItem.Size = New System.Drawing.Size(95, 21)
        Me.MyAccountToolStripMenuItem.Text = "My Account"
        '
        'AdminToolStripMenuItem
        '
        Me.AdminToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CheckMembersDetailsToolStripMenuItem, Me.CheckStockToolStripMenuItem, Me.OrderFromSupplierToolStripMenuItem, Me.GenerateReportToolStripMenuItem, Me.MemberRegistrationToolStripMenuItem})
        Me.AdminToolStripMenuItem.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AdminToolStripMenuItem.Name = "AdminToolStripMenuItem"
        Me.AdminToolStripMenuItem.Size = New System.Drawing.Size(61, 21)
        Me.AdminToolStripMenuItem.Text = "Admin"
        '
        'CheckMembersDetailsToolStripMenuItem
        '
        Me.CheckMembersDetailsToolStripMenuItem.Name = "CheckMembersDetailsToolStripMenuItem"
        Me.CheckMembersDetailsToolStripMenuItem.Size = New System.Drawing.Size(228, 22)
        Me.CheckMembersDetailsToolStripMenuItem.Text = "Check Member's Details"
        '
        'CheckStockToolStripMenuItem
        '
        Me.CheckStockToolStripMenuItem.Name = "CheckStockToolStripMenuItem"
        Me.CheckStockToolStripMenuItem.Size = New System.Drawing.Size(228, 22)
        Me.CheckStockToolStripMenuItem.Text = "Check Stock"
        '
        'OrderFromSupplierToolStripMenuItem
        '
        Me.OrderFromSupplierToolStripMenuItem.Enabled = False
        Me.OrderFromSupplierToolStripMenuItem.Name = "OrderFromSupplierToolStripMenuItem"
        Me.OrderFromSupplierToolStripMenuItem.Size = New System.Drawing.Size(228, 22)
        Me.OrderFromSupplierToolStripMenuItem.Text = "Order From Supplier"
        '
        'GenerateReportToolStripMenuItem
        '
        Me.GenerateReportToolStripMenuItem.Name = "GenerateReportToolStripMenuItem"
        Me.GenerateReportToolStripMenuItem.Size = New System.Drawing.Size(228, 22)
        Me.GenerateReportToolStripMenuItem.Text = "Generate Report"
        '
        'MemberRegistrationToolStripMenuItem
        '
        Me.MemberRegistrationToolStripMenuItem.Name = "MemberRegistrationToolStripMenuItem"
        Me.MemberRegistrationToolStripMenuItem.Size = New System.Drawing.Size(228, 22)
        Me.MemberRegistrationToolStripMenuItem.Text = "Member Registration"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(69, 21)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Font = New System.Drawing.Font("Cambria", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(49, 21)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'lblTime
        '
        Me.lblTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTime.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.Location = New System.Drawing.Point(12, 147)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(137, 43)
        Me.lblTime.TabIndex = 81
        '
        'Timer1
        '
        '
        'OrderFromSupplier
        '
        Me.AcceptButton = Me.btnView
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightCyan
        Me.ClientSize = New System.Drawing.Size(594, 527)
        Me.Controls.Add(Me.lblTime)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.picLogo)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.picFbPage)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "OrderFromSupplier"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Starbucks"
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.picFbPage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picLogo As System.Windows.Forms.PictureBox
    Friend WithEvents btnView As System.Windows.Forms.Button
    Friend WithEvents CboSupplier As System.Windows.Forms.ComboBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CboProductID As System.Windows.Forms.ComboBox
    Friend WithEvents lblSupplier As System.Windows.Forms.Label
    Friend WithEvents picFbPage As System.Windows.Forms.PictureBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ProductToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MyCartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaymentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TopUpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MyAccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AdminToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckMembersDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckStockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OrderFromSupplierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GenerateReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MemberRegistrationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
End Class

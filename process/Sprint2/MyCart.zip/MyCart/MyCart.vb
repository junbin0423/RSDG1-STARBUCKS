﻿Imports System.Data.OleDb
Imports System.IO
Public Class MyCart
    'For database uses only (*)
    Dim provider As String
    Dim dataFile As String
    Dim connString As String
    Dim myConnection As OleDbConnection = New OleDbConnection
    Dim dr As OleDbDataReader

    Private Sub MyCart_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'For database uses only (*)
        provider = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source ="
        dataFile = Login.strFileName & "Starbucks_Database.accdb"
        connString = provider & dataFile
        myConnection.ConnectionString = connString

        If Login.strUserType = "Admin" Then
            AdminToolStripMenuItem.Enabled = True
        Else
            AdminToolStripMenuItem.Enabled = False
        End If

        display_Items_In_MyCart()

        Timer1.Start()
    End Sub

    Private Sub picFbPage_Click(sender As Object, e As EventArgs) Handles picFbPage.Click
        Process.Start(Login.strFileName & "Resources\Starbucks.html")
    End Sub

    Private Sub display_Items_In_MyCart()
        Dim strFile As String = Login.strFileName & "myCart.txt"
        Dim dblTotalAmount As Double

        If File.Exists(strFile) = True Then
            Dim objReader As New StreamReader(strFile)
            Dim strText As String
            Dim strArray(3) As String

            DataGridView1.Rows.Clear()

            'Construct columns
            DataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            DataGridView1.BackgroundColor = System.Drawing.SystemColors.Control

            DataGridView1.ColumnCount = 4
            DataGridView1.Columns(0).Name = "Product Name"
            DataGridView1.Columns(1).Name = "Quantity"
            DataGridView1.Columns(0).DefaultCellStyle.WrapMode = DataGridViewTriState.False

            DataGridView1.Columns(2).Name = "Price Per Unit(RM)"
            DataGridView1.Columns(3).Name = "Sub Total(RM)"
            Me.DataGridView1.Font = New Font("Comic Sans Ms", 10)

            Dim row As Object()
            While objReader.Peek <> -1
                strText = objReader.ReadLine()
                strArray = strText.Split("#")
                row = New Object() {strArray(0), strArray(1), FormatNumber(CDbl(strArray(2)), 2), FormatNumber(CInt(strArray(1)) * CDbl(strArray(2)), 2)}
                DataGridView1.Rows.Add(row)
                dblTotalAmount += CInt(strArray(1)) * CDbl(strArray(2))
            End While
            objReader.Close()

            lblTotalAmount.Text = FormatNumber(dblTotalAmount, 2)
        End If
    End Sub

    Private Sub DataGridView1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.DoubleClick
        Dim i As Integer
        Dim strOldFile As String = Login.strFileName & "myCart.txt"
        Dim strNewFile As String = Login.strFileName & "temp.txt"
        Dim strText As String
        Dim strArray(3) As String
        Dim strProductName As String

        If File.Exists(strOldFile) = True Then
            Dim objReader As New StreamReader(strOldFile)
            Dim objWriter As New StreamWriter(strNewFile, True)

            i = DataGridView1.CurrentRow.Index
            strProductName = DataGridView1.Item(0, i).Value
            While objReader.Peek <> -1
                strText = objReader.ReadLine()
                strArray = strText.Split("#")
                If strArray(0) = strProductName Then
                    MessageBox.Show("Remove successfull", "Remove Item", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    objWriter.WriteLine(strText)
                End If
            End While

            objWriter.Close()
            objReader.Close()

            File.Delete(strOldFile)
            My.Computer.FileSystem.RenameFile(strNewFile, "myCart.txt")

            display_Items_In_MyCart()
        End If
    End Sub

    Private Sub btnPayment_Click(sender As Object, e As EventArgs) Handles btnPayment.Click
        Payment.Show()
        Me.Close()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click
        Dim objReader As New StreamReader(Login.strFileName & "Resources\Instruction.txt")
        Dim strText As String
        Dim strArray(8) As String

        While objReader.Peek <> -1
            strText = objReader.ReadToEnd
            strArray = strText.Split("#")
        End While

        MessageBox.Show(strArray(1), "HELP", MessageBoxButtons.OK, MessageBoxIcon.Information)
        objReader.Close()
    End Sub

    Private Sub LogOutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogOutToolStripMenuItem.Click
        Dim FileToDelete As String = Login.strFileName & "myCart.txt"

        If File.Exists(FileToDelete) = True Then
            File.Delete(FileToDelete)
        End If

        Login.Close()
        Login.Show()
        Me.Close()
    End Sub

    Private Sub CheckMembersDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CheckMembersDetailsToolStripMenuItem.Click
        CheckMemberDetails.Show()
        Me.Close()
    End Sub

    Private Sub CheckStockToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CheckStockToolStripMenuItem.Click
        CheckStock.Show()
        Me.Close()
    End Sub

    Private Sub OrderFromSupplierToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OrderFromSupplierToolStripMenuItem.Click
        OrderFromSupplier.Show()
        Me.Close()
    End Sub

    Private Sub GenerateReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GenerateReportToolStripMenuItem.Click
        GenerateReport.Show()
        Me.Close()
    End Sub

    Private Sub MyAccountToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MyAccountToolStripMenuItem.Click
        MyAccount.Show()
        Me.Close()
    End Sub

    Private Sub TopUpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TopUpToolStripMenuItem.Click
        TopUp.Show()
        Me.Close()
    End Sub

    Private Sub PaymentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PaymentToolStripMenuItem.Click
        Payment.Show()
        Me.Close()
    End Sub

    Private Sub ProductToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductToolStripMenuItem.Click
        Product.Show()
        Me.Close()
    End Sub

    
    Private Sub MemberRegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MemberRegistrationToolStripMenuItem.Click
        Registration.Show()
        Me.Close()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblTime.Text = "Date: " & Format(Date.Now(), "dd/MM/yy") & vbCr & "Time: " & TimeOfDay.ToString("h:mm:ss tt")
    End Sub
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StartApps
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(StartApps))
        Me.chkLicense = New System.Windows.Forms.CheckBox()
        Me.picLogo = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtLicense = New System.Windows.Forms.RichTextBox()
        Me.btnDisagree = New System.Windows.Forms.Button()
        Me.btnAgree = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'chkLicense
        '
        Me.chkLicense.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkLicense.Location = New System.Drawing.Point(320, 244)
        Me.chkLicense.Name = "chkLicense"
        Me.chkLicense.Size = New System.Drawing.Size(272, 24)
        Me.chkLicense.TabIndex = 63
        Me.chkLicense.Text = "I have read the following term of use:"
        Me.chkLicense.UseVisualStyleBackColor = True
        '
        'picLogo
        '
        Me.picLogo.BackColor = System.Drawing.Color.Transparent
        Me.picLogo.Image = CType(resources.GetObject("picLogo.Image"), System.Drawing.Image)
        Me.picLogo.Location = New System.Drawing.Point(6, 9)
        Me.picLogo.Name = "picLogo"
        Me.picLogo.Size = New System.Drawing.Size(123, 74)
        Me.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLogo.TabIndex = 62
        Me.picLogo.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(0, -1)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(302, 445)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 61
        Me.PictureBox2.TabStop = False
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(317, 47)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(191, 29)
        Me.Label1.TabIndex = 60
        Me.Label1.Text = "End User License Agreement"
        '
        'txtLicense
        '
        Me.txtLicense.BackColor = System.Drawing.Color.White
        Me.txtLicense.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLicense.Location = New System.Drawing.Point(317, 79)
        Me.txtLicense.Name = "txtLicense"
        Me.txtLicense.ReadOnly = True
        Me.txtLicense.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.txtLicense.Size = New System.Drawing.Size(323, 159)
        Me.txtLicense.TabIndex = 59
        Me.txtLicense.Text = ""
        '
        'btnDisagree
        '
        Me.btnDisagree.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnDisagree.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisagree.Location = New System.Drawing.Point(485, 312)
        Me.btnDisagree.Name = "btnDisagree"
        Me.btnDisagree.Size = New System.Drawing.Size(83, 33)
        Me.btnDisagree.TabIndex = 58
        Me.btnDisagree.Text = "Disagree"
        Me.ToolTip1.SetToolTip(Me.btnDisagree, "Click here if you disagree the end user license agreement.")
        Me.btnDisagree.UseVisualStyleBackColor = True
        '
        'btnAgree
        '
        Me.btnAgree.BackColor = System.Drawing.SystemColors.Control
        Me.btnAgree.Enabled = False
        Me.btnAgree.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAgree.Location = New System.Drawing.Point(384, 312)
        Me.btnAgree.Name = "btnAgree"
        Me.btnAgree.Size = New System.Drawing.Size(83, 33)
        Me.btnAgree.TabIndex = 57
        Me.btnAgree.Text = "Agree"
        Me.ToolTip1.SetToolTip(Me.btnAgree, "Click here if you agree the  end user license agreement.")
        Me.btnAgree.UseVisualStyleBackColor = False
        '
        'StartApps
        '
        Me.AcceptButton = Me.btnAgree
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightCyan
        Me.CancelButton = Me.btnDisagree
        Me.ClientSize = New System.Drawing.Size(650, 444)
        Me.Controls.Add(Me.chkLicense)
        Me.Controls.Add(Me.picLogo)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtLicense)
        Me.Controls.Add(Me.btnDisagree)
        Me.Controls.Add(Me.btnAgree)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "StartApps"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Starbucks"
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents chkLicense As System.Windows.Forms.CheckBox
    Friend WithEvents picLogo As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtLicense As System.Windows.Forms.RichTextBox
    Friend WithEvents btnDisagree As System.Windows.Forms.Button
    Friend WithEvents btnAgree As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
End Class

﻿Imports System.IO
Public Class StartApps
    Private Sub StartApps_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim objReader As New System.IO.StreamReader(Login.strFileName & "Resources\License.txt")
        txtLicense.Text = objReader.ReadToEnd
        txtLicense.Multiline = True
        txtLicense.ScrollBars = RichTextBoxScrollBars.Vertical

        clear_Previous_User_Cart()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnDisagree.Click
        Me.Close()
    End Sub

    Private Sub btnAgree_Click(sender As Object, e As EventArgs) Handles btnAgree.Click
        Login.Show()
        Me.Close()
    End Sub

    Private Sub chkLicense_CheckedChanged(sender As Object, e As EventArgs) Handles chkLicense.CheckedChanged
        If chkLicense.Checked = True Then
            btnAgree.Enabled = True
        ElseIf chkLicense.Checked = False Then
            btnAgree.Enabled = False
        End If
    End Sub

    Private Sub clear_Previous_User_Cart()
        Dim FileToDelete As String = Login.strFileName & "myCart.txt"

        If File.Exists(FileToDelete) = True Then
            File.Delete(FileToDelete)
        End If
    End Sub
End Class